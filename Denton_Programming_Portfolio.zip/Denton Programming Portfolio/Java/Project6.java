/**
 * Project 6 java file.
 *
 * @author Brian Denton
 */
 
 class Project6{
 
        public static void main( String[] args ){
   
        MainFrame newGame = new MainFrame();
        
        newGame.setVisible( true );
        
    }
    
}
