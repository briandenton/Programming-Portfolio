#!/bin/bash

# Compile components into Java bytecode

javac GameMaster.java
javac InvalidClickException.java
javac State.java
javac Square.java
javac GamePanel.java
javac MainFrame.java
javac Project6.java

# Run Project 6 on JVM
java Project6
