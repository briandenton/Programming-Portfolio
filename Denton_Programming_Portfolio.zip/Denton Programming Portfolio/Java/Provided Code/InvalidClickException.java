public class InvalidClickException extends Exception {
	public InvalidClickException(String msg, int squareState, int gameState) {
		// TODO Complete the method.
	}

	// TODO Add additional methods to retrieve the information in the exception.

}
