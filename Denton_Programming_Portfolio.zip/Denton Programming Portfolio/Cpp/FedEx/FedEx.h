/*///////////////////////////////////////////////////////////////////////////////////////

FILENAME:	 FedEx.h

AUTHOR:      Brian Denton

DATE:		 09/23/2009

PROJECT:	 CSCI 362 Data Structures - Programming Assignment 3

DESCRIPTION: Header file for driver program in FedEx simulation.


///////////////////////////////////////////////////////////////////////////////////////*/


#ifndef FEDEX_H
#define FEDEX_H

#include "utility.h"
#include "Simulator.h"


#endif

//END OF PROGRAM