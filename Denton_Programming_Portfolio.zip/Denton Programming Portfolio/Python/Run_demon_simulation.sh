#!/bin/bash

python demon.py
